/*
 * Media Manager — Box document preview (BoxPreview Visualforce page).
 * Renders the file with the Box Content Preview Library (window.Box.Preview)
 * using the single-file, preview-only token the page action issued server-side.
 */
(function () {
    'use strict';

    var container = document.getElementById('box-preview');
    var message = document.getElementById('box-preview-message');
    var fileId = container.dataset.fileId;
    var token = container.dataset.token;

    if (!fileId || !token || !window.Box || !window.Box.Preview) {
        container.hidden = true;
        message.hidden = false;
        return;
    }

    var preview = new window.Box.Preview();
    // Media Manager provides its own header and download actions.
    preview.show(fileId, token, {
        container: '#box-preview',
        header: 'none',
        showDownload: false,
        showAnnotations: false
    });
})();
