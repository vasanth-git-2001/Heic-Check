/*
 * Media Manager — Box OAuth 2.0 callback (BoxOAuthCallback Visualforce page).
 * Closes the sign-in pop-up after a successful authorization; the setup wizard
 * notices the closed window and verifies the connection.
 */
(function () {
    'use strict';

    var result = document.getElementById('box-oauth');
    if (result && result.dataset.success === 'true') {
        setTimeout(function () {
            window.close();
        }, 1500);
    }
})();
